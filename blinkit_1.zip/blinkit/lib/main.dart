import 'package:blinkit/screens/authScreen.dart';
import 'package:blinkit/screens/homescreen.dart';
import 'package:blinkit/shared/bannerStack.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    //home:HomeScreen(),
    //home: BannerStack(),
    home: AuthScreen(),
  ));
}
